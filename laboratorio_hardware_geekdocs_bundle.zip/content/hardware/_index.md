---
title: "Laboratorio de Hardware - Trabajo Final Integrador"
weight: 1
---

Bienvenido/a a la documentación del Trabajo Final Integrador. A continuación encontrarás:

- Justificación de la selección de componentes
- Requisitos recomendados de hardware
- Presupuesto detallado
- Conclusión
