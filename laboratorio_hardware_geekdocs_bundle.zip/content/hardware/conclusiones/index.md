---
title: "Conclusiones"
weight: 5
---

# 🧾 Conclusión

La elección se basó en dar prioridad a la **motherboard**, el **procesador** y la **placa de video**, lo cual se vio reflejado también en el presupuesto.

...
