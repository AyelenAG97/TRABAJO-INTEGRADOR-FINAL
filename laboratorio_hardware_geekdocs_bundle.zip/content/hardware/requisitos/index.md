---
title: "Requisitos"
weight: 3
---

# Requisitos de Sistema para Juegos

![Logo CompraGamer](/images/compragamer-logo.png)

Los componentes y sus precios fueron extraídos de CompraGamer.

...
